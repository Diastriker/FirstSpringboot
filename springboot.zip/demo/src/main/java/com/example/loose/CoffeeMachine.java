package com.example.loose;

public interface CoffeeMachine {
	String brew();
}
