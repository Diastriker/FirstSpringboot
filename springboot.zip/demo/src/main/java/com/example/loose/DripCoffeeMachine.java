package com.example.loose;

public class DripCoffeeMachine implements CoffeeMachine {
	public String brew() {
		return "드립머신으로 커피를 추출한다";
	}
}
