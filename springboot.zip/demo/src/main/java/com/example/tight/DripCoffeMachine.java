package com.example.tight;

public class DripCoffeMachine {
	public String brew() {
		return "드립커피머신으로 커피 추출하기";
	}
}
