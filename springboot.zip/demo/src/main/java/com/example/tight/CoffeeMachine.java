package com.example.tight;

public interface CoffeeMachine {
	String brew();
}
