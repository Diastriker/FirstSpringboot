package com.example.tight;

public class EspressoMachine {
	public String brew() {
		return "에스프레소 머신으로 커피 추출하기";
	}
}
