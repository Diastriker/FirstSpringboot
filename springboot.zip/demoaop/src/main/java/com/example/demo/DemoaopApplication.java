package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoaopApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoaopApplication.class, args);
	}

}
