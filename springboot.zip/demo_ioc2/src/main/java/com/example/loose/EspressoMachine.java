package com.example.loose;

import org.springframework.stereotype.Component;

@Component
public class EspressoMachine implements CoffeeMachine {

	@Override
	public String brew() {
		return "에스프레소 머신으로 커피를 추출한다";
	}

}
